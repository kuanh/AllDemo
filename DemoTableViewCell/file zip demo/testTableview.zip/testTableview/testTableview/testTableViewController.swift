//
//  testTableViewController.swift
//  testTableview
//
//  Created by BTR on 25.11.14.
//  Copyright (c) 2014 BTR. All rights reserved.
//

import UIKit

class testTableViewController: UITableViewController {

    var allObjectArray: NSMutableArray = []
    var elements: NSMutableArray = []
    
    var currentPage = 0
    var nextpage = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        for var i = 0; i <= 500; i++ {
            allObjectArray.addObject(i)
        }
        elements.addObjectsFromArray(allObjectArray.subarrayWithRange(NSMakeRange(0, 20)))
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete method implementation.
        // Return the number of rows in the section.
        return elements.count
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath) as UITableViewCell

cell.textLabel.text = "cell"
        return cell
    }
   
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        println(indexPath.row)
        nextpage = elements.count - 5
        if indexPath.row == nextpage {
            currentPage++
            nextpage = elements.count - 5
            elements.addObjectsFromArray(allObjectArray.subarrayWithRange(NSMakeRange(currentPage, 20)))
                tableView.reloadData()
        }
    }
}
