//
//  MyDataShow.swift
//  EditDelAddData
//
//  Created by KuAnh on 18/10/2017.
//  Copyright © 2017 KuAnh. All rights reserved.
//

import UIKit

class MyDataShow: NSObject, UITableViewDelegate, UITableViewDataSource {
    
    var arrayNumber = [Int](0...4)
    var arrayTextString = ["1","5","4","3","2"]
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        
        return arrayNumber.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "123", for: indexPath)
        cell.textLabel?.text = "\(arrayNumber[indexPath.row])"
        cell.detailTextLabel?.text = arrayTextString[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        
        return true
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        tableView.reloadData()
        if editingStyle == .delete {
            arrayNumber.remove(at: indexPath.row)
            arrayTextString.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
        if arrayNumber.isEmpty {
            let vc = ShowDataTableViewController()
            vc.showAlertVC(title: "Thong Bao", message: "K co du lieu")
        }
    }
}
