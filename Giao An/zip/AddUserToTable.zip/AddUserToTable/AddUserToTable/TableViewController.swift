//
//  TableViewController.swift
//  AddUserToTable
//
//  Created by Chris Upjohn on 20/01/2015.
//  Copyright (c) 2015 Chris Upjohn. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController, UIAlertViewDelegate {
    
    var users: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return users.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath) as UITableViewCell
        
        // Set the label text as the users name
        cell.textLabel!.text = users[indexPath.row]
        
        return cell
    }
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        if buttonIndex == 1 {
            users.append(alertView.textFieldAtIndex(0)!.text)
            tableView.reloadData()
        }
    }
    
    @IBAction func addUser(sender: AnyObject) {
        var alert = UIAlertView(title: "Enter users name", message: nil, delegate: self, cancelButtonTitle: "Cancel")
        
        alert.addButtonWithTitle("Done")
        alert.alertViewStyle = UIAlertViewStyle.PlainTextInput
        alert.show()
    }
    
}

































