//
//  Car.swift
//  SearchbarTutorial
//
//  Created by Marco Aurelio Viana Almeida on 12/16/15.
//  Copyright © 2015 appscg.com. All rights reserved.
//

import Foundation

struct Car {
    let type : String
    let maker : String
    let model : String
    let image : String
}
