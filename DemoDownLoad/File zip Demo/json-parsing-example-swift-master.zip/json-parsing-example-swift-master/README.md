json-parsing-example-swift
==========================

In this tutorial, we will create simple application called JSONDemo which describes how to parse JSON data. JSON is stands for JavaScript Object Notation, JSON provides simple interface for storing and exchanging data. JSON Parsing example is very simple and easy human readable format that is used to send and receive data over network.

You can find complete tutorial on how to use the code repo here : [JSON Parsing Example in Swift](http://www.theappguruz.com/blog/json-parsing-example-swift)

This Tutorial has been presented by The App Guruz - One of the best [iPhone Development Company in India](http://www.theappguruz.com/iphone-app-development/)
