//
//  DetailsViewController.swift
//  DemoLifeCycle
//
//  Created by Trương Thắng on 3/6/17.
//  Copyright © 2017 Trương Thắng. All rights reserved.
//

import UIKit

class DetailsViewController: UIViewController {
    
    @IBOutlet weak var detailDescriptionLabel: UILabel!
    
    
    func configureView() {
        // Update the user interface for the detail item.
        if let detail = detailItem {
            if let label = detailDescriptionLabel {
                label.text = detail.description
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
                navigationController?.navigationBar.isHidden = true
        // Do any additional setup after loading the view, typically from a nib.
        print("\n\nself\(self)")
        configureView()
        print("\t\(type(of: self)) - View da dc load len")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("\t\(type(of: self)) - View sap duoc hien len")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("\t\(type(of: self)) - View da hien len roi")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("\t\(type(of: self)) - View chuan bi bien mat")
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("\t\(type(of: self)) - View da bien mat")
        
    }
    
    deinit {
        print("\t \(type(of: self)) - Tao di chet day")
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var detailItem: NSDate? {
        didSet {
            // Update the view.
            configureView()
        }
    }
    
    @IBAction func goBack(_ sender: UIButton) {
        print("\n\n")
        self.navigationController?.popViewController(animated: true)
    }
    


}
