//
//  Weather.swift
//  DemoRequestAPIWeather
//
//  Created by HoangAnh on 12/15/17.
//  Copyright © 2017 HoangAnh. All rights reserved.
//

import UIKit

class Weather: NSObject {
    var name: String
    var country: String
    var localtime: String
    
    init(name: String, country: String, localtime: String) {
        self.name = name
        self.country = country
        self.localtime = localtime
    }
}
