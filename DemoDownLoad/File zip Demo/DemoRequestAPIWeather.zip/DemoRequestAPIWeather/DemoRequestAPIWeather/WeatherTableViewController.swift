//
//  WeatherTableViewController.swift
//  DemoRequestAPIWeather
//
//  Created by HoangAnh on 12/15/17.
//  Copyright © 2017 HoangAnh. All rights reserved.
//

import UIKit

class WeatherTableViewController: UITableViewController {
    
    var arrayData: Array<Weather> = Array<Weather>()

    override func viewDidLoad() {
        super.viewDidLoad()
        getDataFromURL("http://api.apixu.com/v1/current.json?key=945794ffd0e145d084985934171412&q=Paris")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return arrayData.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! WeatherTableViewCell
        cell.name.text = arrayData[indexPath.row].name
        cell.country.text = arrayData[indexPath.row].country
        cell.localtime.text = arrayData[indexPath.row].localtime

        return cell
    }
 

    func getDataFromURL(_ link: String) {
        let url: URL = URL(string: link)!
        let task = URLSession.shared.dataTask(with: url, completionHandler: { (data, reponse, error) in
            guard let _data = data, let _reponse = reponse, error == nil else {return}
            
            do {
                let json = try JSONSerialization.jsonObject(with: _data, options: .allowFragments) as! [String : Any]
                guard let location = json["location"] as? [String : Any] else {return}
                if let name = location["name"] as? String {
                    if let country = location["country"] as? String{
                        if let localtime = location["localtime"] as? String {
                            self.arrayData.append(Weather(name: name, country: country, localtime: localtime))
                            print(self.arrayData.count)     
                        }
                    }
                }
                print(location)
            } catch let error as NSError {
                print(error)
            }
            })
        task.resume()
    }

    

}
